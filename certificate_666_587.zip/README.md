# Ordinary-coordinate6x6 multiplication: 587 additions,153 products

Unpack this archive and run `python3 -I -B verify.py`. Only Python's standard
library is required. It checks file hashes, expands the pinned source, replays
both JSON and literal SLPs, checks coordinated term signs, and verifies all
46,656 matrix-multiplication tensor coefficients exactly.

The operation count is 158+157+272=587 binary additions/
subtractions and153 products, or 740 total scalar operations. Inputs are
ordinary row-major A and B entries. Compute u.slp and v.slp, multiply their153
outputs pairwise, then apply w.slp. Decoder output6*j+i is C[i,j], a free storage
permutation. There is no basis conversion, unary-negation gate, or nonunit scalar
gate. The integer identity works over any ring with the usual bilinear semantics.

Source: Andrey Perminov's rank153 decomposition, public catalogue commit
64f58a5e40806bc47847b11dd8aceec043fa895d, source file recorded in scheme.json.
The construction uses LEO donor programs from the historical reducer revision
and the new DistanceScorer PR revision, both recorded in scheme.json.

The previous local certificate used590 additions. We pool exact intermediate
vectors from several reducers, preserving magnitudes and identifying only signs.
The new step searches small exchanges of existing helpers for new helpers; exact
production closure permits all required targets to act as intermediates and
reconstructs an acyclic circuit. The output map is searched transposed, then
transposed back with the153-36=117 count adjustment. All factor/interface signs
are chosen jointly so the final program uses literal binary+/- gates.

This is a verified improvement for the named fixed decomposition. It is not a
global optimality/priority claim, rank or exponent improvement, or a measured
runtime improvement. The public source program has655 additions. The exact comparator for this pass
is the previous590-addition certificate.
