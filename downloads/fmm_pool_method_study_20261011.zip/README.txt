Testing Perminov's weighted helper pool, 11 October 2026

This is a study of fixed linear maps, with no new addition record.
From this extracted directory, run with standard-library Python 3.10+:

python3 -I -B methods/linear/reconstruction/pool_method_study/verify.py
python3 -B -m unittest discover -s methods/linear/reconstruction/pool_method_adapters -p 'test_*.py'

NumPy scoring controls are skipped when NumPy is unavailable. Native sampling
requires a separate clean upstream checkout at the pinned commit and C++17.
Read docs/perminov-pool-method-20261011.md and the module READMEs.
Default replay checks arithmetic and the finite88 upper witness; it does not
verify an UNSAT certificate. Optional OR-Tools model reruns are separate.
