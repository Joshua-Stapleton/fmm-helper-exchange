#!/usr/bin/env python3
import importlib.util,json
from pathlib import Path
H=Path(__file__).resolve().parent
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
print(json.dumps(dict(map=module('map41',H/'verify.py').verify(),exchange=module('toy',H/'three_for_two/verify_small.py').verify()),indent=2))
