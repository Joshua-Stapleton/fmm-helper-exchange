Run python3 -I -B verify_all.py after extraction. Standard-library Python only.
Checks an original signed 38x16 V map using 41 additions and a four-input
seven-to-six local helper-exchange counterexample. No basis change or complete
FMM tensor claim. The 41 was found by Andrey Perminov's unmodified LEO solver.
Details: https://github.com/Joshua-Stapleton/fmm-helper-exchange/blob/main/docs/344-and-exchange-20261017.md
